<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>employmentStatus</name>
   <tag></tag>
   <elementGuidId>bfd745ef-8e28-4282-931f-efa4548a017c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section > div > div > div > div.row.left-detail > div:nth-child(1) > div > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section > div > div > div > div.row.left-detail > div:nth-child(1) > div > div</value>
   </webElementProperties>
</WebElementEntity>
