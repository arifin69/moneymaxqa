<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>employment</name>
   <tag></tag>
   <elementGuidId>d530ef2c-1d54-4743-a1b9-c6dc84d8446b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section > div > div > div > div.row.left-detail > div:nth-child(1) > div > div > #employer_status > option:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section > div > div > div > div.row.left-detail > div:nth-child(1) > div > div > #employer_status > option:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
