<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>applyNoPartnerMobile</name>
   <tag></tag>
   <elementGuidId>bf8f2e26-3534-4455-a017-468eb4d956b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > div.background-01.personal-archive-page > div.container-fluid > div > div.container > div > div.col-sm-8.col-md-9.right-content > div.col-sm-12.text-center.frame-no-data > div > ul > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > div.background-01.personal-archive-page > div.container-fluid > div > div.container > div > div.col-sm-8.col-md-9.right-content > div.col-sm-12.text-center.frame-no-data > div > ul > li > a</value>
   </webElementProperties>
</WebElementEntity>
