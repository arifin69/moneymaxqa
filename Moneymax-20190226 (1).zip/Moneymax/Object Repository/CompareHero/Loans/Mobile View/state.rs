<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>state</name>
   <tag></tag>
   <elementGuidId>02d6aaef-a0d4-43b2-bae7-cf85d8dc6b0f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#personal-info > div > div > div > form > div:nth-child(7) > div > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#personal-info > div > div > div > form > div:nth-child(7) > div > div</value>
   </webElementProperties>
</WebElementEntity>
