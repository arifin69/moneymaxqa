<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>status</name>
   <tag></tag>
   <elementGuidId>356e1506-0faf-4b92-8bb3-cee26b97a550</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#employer_status > option:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#employer_status > option:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
