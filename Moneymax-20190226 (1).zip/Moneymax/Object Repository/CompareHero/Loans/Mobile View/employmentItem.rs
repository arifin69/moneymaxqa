<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>employmentItem</name>
   <tag></tag>
   <elementGuidId>5f68aaae-5619-4afb-a451-ecd5a48a48b6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#personal-info > div > div > div > form > div:nth-child(8) > div > div > #employment_status_info > option:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#personal-info > div > div > div > form > div:nth-child(8) > div > div > #employment_status_info > option:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
