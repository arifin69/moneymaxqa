<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>applyNoPartner</name>
   <tag></tag>
   <elementGuidId>40cf2959-e366-467f-9be4-b2027c3552e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > div.background-01.personal-archive-page > div.container-fluid > div > div.container > div > div.col-sm-8.col-md-9.right-content > div.col-sm-12.text-center.frame-no-data > div > ul > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > div.background-01.personal-archive-page > div.container-fluid > div > div.container > div > div.col-sm-8.col-md-9.right-content > div.col-sm-12.text-center.frame-no-data > div > ul > li > a</value>
   </webElementProperties>
</WebElementEntity>
