<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ccNo</name>
   <tag></tag>
   <elementGuidId>da478519-8bc0-4a5b-acb4-01eb8b9197ed</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#step4 > div > div:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#step4 > div > div:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
