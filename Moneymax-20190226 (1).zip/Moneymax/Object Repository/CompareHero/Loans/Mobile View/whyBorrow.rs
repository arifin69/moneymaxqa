<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>whyBorrow</name>
   <tag></tag>
   <elementGuidId>e9f428dd-fb69-4b2b-90a6-c5434f6b68e0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#reason-borrow > option:nth-child(3)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#reason-borrow > option:nth-child(3)</value>
   </webElementProperties>
</WebElementEntity>
