<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>apply</name>
   <tag></tag>
   <elementGuidId>0961612f-cf2e-4571-9494-074b910f254e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#list-data > div:nth-child(1) > div.panel-body.card-product-body > div:nth-child(1) > div.col-sm-4.col-sm-push-8.col-md-3.col-md-push-9.wrapper-right > div.row.visible-xs.visible-sm > div:nth-child(2) > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#list-data > div:nth-child(1) > div.panel-body.card-product-body > div:nth-child(1) > div.col-sm-4.col-sm-push-8.col-md-3.col-md-push-9.wrapper-right > div.row.visible-xs.visible-sm > div:nth-child(2) > button</value>
   </webElementProperties>
</WebElementEntity>
