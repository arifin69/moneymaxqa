<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonLoan</name>
   <tag></tag>
   <elementGuidId>fead6b8b-a14e-43b3-af76-75187c26524b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section.header-content.no_background.no_filter > div > div > div.col-sm-8.col-md-6.three-box > div > div:nth-child(2) > div > div > a.btn.btn-success.btn-full</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section.header-content.no_background.no_filter > div > div > div.col-sm-8.col-md-6.three-box > div > div:nth-child(2) > div > div > a.btn.btn-success.btn-full</value>
   </webElementProperties>
</WebElementEntity>
