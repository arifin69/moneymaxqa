<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CreditHistory</name>
   <tag></tag>
   <elementGuidId>fda787fc-233e-43c8-9588-7575d011c165</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#credit_status > option:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#credit_status > option:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
