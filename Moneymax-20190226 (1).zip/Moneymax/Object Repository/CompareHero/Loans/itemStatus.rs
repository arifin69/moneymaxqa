<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>itemStatus</name>
   <tag></tag>
   <elementGuidId>7a8d3610-232b-4c0b-a0cc-c6a8d405f63b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#personal-info > div > div > div > form > div:nth-child(8) > div > div > #employment_status_info > option:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#personal-info > div > div > div > form > div:nth-child(8) > div > div > #employment_status_info > option:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
