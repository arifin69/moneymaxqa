<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>currentJob</name>
   <tag></tag>
   <elementGuidId>d72c03fe-eb17-44c0-814b-1fb676241882</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#current_job > div > div > div > div:nth-child(2) > label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#current_job > div > div > div > div:nth-child(2) > label</value>
   </webElementProperties>
</WebElementEntity>
