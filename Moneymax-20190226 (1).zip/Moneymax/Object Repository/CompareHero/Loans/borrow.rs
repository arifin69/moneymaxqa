<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>borrow</name>
   <tag></tag>
   <elementGuidId>92f6643d-95f1-4572-89a3-328f9ce3f5b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#reason-borrow</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#reason-borrow > option:nth-child(3)</value>
   </webElementProperties>
</WebElementEntity>
