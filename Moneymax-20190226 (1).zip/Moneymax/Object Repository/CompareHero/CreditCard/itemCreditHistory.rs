<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>itemCreditHistory</name>
   <tag></tag>
   <elementGuidId>0878e9fe-dfbd-4c1e-9681-504abbeadaa0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section > div > div > div > div.row.left-detail > div:nth-child(1) > div > div > #credit_status > option:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section > div > div > div > div.row.left-detail > div:nth-child(1) > div > div > #credit_status > option:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
