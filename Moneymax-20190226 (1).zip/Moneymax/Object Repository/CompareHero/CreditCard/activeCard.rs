<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>activeCard</name>
   <tag></tag>
   <elementGuidId>6e931b1c-5f5a-4731-a007-05c159dcb5aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#active_card > div > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#active_card > div > div</value>
   </webElementProperties>
</WebElementEntity>
