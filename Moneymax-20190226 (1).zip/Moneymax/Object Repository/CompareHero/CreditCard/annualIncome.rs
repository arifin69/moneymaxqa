<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>annualIncome</name>
   <tag></tag>
   <elementGuidId>65d4832e-1b61-4c02-9837-5b4b1c1822d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#collapse1 > form > div:nth-child(1) > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#collapse1 > form > div:nth-child(1) > div</value>
   </webElementProperties>
</WebElementEntity>
