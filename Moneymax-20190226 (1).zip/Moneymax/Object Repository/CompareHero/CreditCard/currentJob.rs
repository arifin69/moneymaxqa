<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>currentJob</name>
   <tag></tag>
   <elementGuidId>22246081-cb0f-4d91-92e0-1e80a0fa4f00</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#step2 > div > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#step2 > div > div</value>
   </webElementProperties>
</WebElementEntity>
