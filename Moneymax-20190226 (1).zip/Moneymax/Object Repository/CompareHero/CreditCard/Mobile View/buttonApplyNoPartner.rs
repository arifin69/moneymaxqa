<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonApplyNoPartner</name>
   <tag></tag>
   <elementGuidId>6c6c3ec3-6b2c-4686-b819-35665ad6407a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > div.background-01.best-deal-page.best-page > div.container-fluid > div > div.container > div > div > div.row > div.col-sm-8.col-md-9.right-content > div.col-sm-12.text-center.frame-no-data > div > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > div.background-01.best-deal-page.best-page > div.container-fluid > div > div.container > div > div > div.row > div.col-sm-8.col-md-9.right-content > div.col-sm-12.text-center.frame-no-data > div > a</value>
   </webElementProperties>
</WebElementEntity>
