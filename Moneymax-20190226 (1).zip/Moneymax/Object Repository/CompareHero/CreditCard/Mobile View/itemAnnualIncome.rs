<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>itemAnnualIncome</name>
   <tag></tag>
   <elementGuidId>392e973c-0386-407a-9943-9687f85d287e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#filter > div > div > div > div:nth-child(4) > div > select > option:nth-child(7)</value>
   </webElementProperties>
</WebElementEntity>
