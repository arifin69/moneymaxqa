<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>activeCard</name>
   <tag></tag>
   <elementGuidId>10747b0b-c171-4dcc-a21a-dcf29ceccdac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#active_card > div > ul > label:nth-child(4)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#active_card > div > ul > label:nth-child(4)</value>
   </webElementProperties>
</WebElementEntity>
