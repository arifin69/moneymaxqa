<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>hsbcOnly</name>
   <tag></tag>
   <elementGuidId>32f67f48-a5e4-4294-b5e9-38fcd589fed4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#filter > div > div > div > div.form-group.credit_card_filter_provider > div:nth-child(14) > label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#filter > div > div > div > div.form-group.credit_card_filter_provider > div:nth-child(14) > label</value>
   </webElementProperties>
</WebElementEntity>
