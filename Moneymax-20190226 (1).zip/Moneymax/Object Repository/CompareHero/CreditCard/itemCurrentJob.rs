<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>itemCurrentJob</name>
   <tag></tag>
   <elementGuidId>24c51351-e69b-4071-9c11-153ad014fd6f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#step2 > div > div > #current_job > option:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#step2 > div > div > #current_job > option:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
