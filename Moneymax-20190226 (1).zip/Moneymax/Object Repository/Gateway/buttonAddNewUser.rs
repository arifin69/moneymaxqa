<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonAddNewUser</name>
   <tag></tag>
   <elementGuidId>8afeef79-5a97-4d3f-a1c8-27083b8807f1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#body > div.gx-container > div.gx-main-container > div > div > div > div.row > div > div > div.gx-card-header > h3 > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#body > div.gx-container > div.gx-main-container > div > div > div > div.row > div > div > div.gx-card-header > h3 > a</value>
   </webElementProperties>
</WebElementEntity>
