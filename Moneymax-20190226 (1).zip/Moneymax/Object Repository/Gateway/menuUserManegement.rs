<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>menuUserManegement</name>
   <tag></tag>
   <elementGuidId>ed5792a9-3f6a-4113-912e-7f482ffe3b4b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#main-menu > ul > li.menu.no-arrow > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#main-menu > ul > li.menu.no-arrow > a</value>
   </webElementProperties>
</WebElementEntity>
