<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>staf</name>
   <tag></tag>
   <elementGuidId>bb14f4cf-b860-4f46-86c2-226d868a52e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#body > div.gx-container > div.gx-main-container > div > div > div.row > div > div > div.gx-card-body > form > div:nth-child(6) > label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#body > div.gx-container > div.gx-main-container > div > div > div.row > div > div > div.gx-card-body > form > div:nth-child(6) > label</value>
   </webElementProperties>
</WebElementEntity>
