<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>remember</name>
   <tag></tag>
   <elementGuidId>05b63085-1edb-406a-b72d-4db0f3097a0e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#body > div.gx-container > div > div > div > div > div > div.login-form > form > fieldset > div.form-group.text-row-between > div > label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#body > div.gx-container > div > div > div > div > div > div.login-form > form > fieldset > div.form-group.text-row-between > div > label</value>
   </webElementProperties>
</WebElementEntity>
