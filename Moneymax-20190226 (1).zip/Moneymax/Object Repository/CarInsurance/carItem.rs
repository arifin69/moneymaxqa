<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>carItem</name>
   <tag></tag>
   <elementGuidId>ef7fb88b-92d4-475b-ab26-75bc6275850f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#car-select > option:nth-child(1)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;car-select&quot;]/option[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#car-select > option:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
