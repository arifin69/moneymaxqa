<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>payingNo</name>
   <tag></tag>
   <elementGuidId>c5130f4f-a132-40cf-8c9b-040caadcb29d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#loan > div > div > div:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#loan > div > div > div:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
