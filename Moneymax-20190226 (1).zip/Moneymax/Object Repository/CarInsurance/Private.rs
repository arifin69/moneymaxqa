<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Private</name>
   <tag></tag>
   <elementGuidId>f60e9286-469b-4b03-8a7f-d8996f64f59a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#car-box > div > div:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#car-box > div > div:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
