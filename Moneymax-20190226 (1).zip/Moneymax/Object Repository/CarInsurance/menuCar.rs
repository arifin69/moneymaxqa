<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>menuCar</name>
   <tag></tag>
   <elementGuidId>ab303cb5-ee44-447c-91d0-0020903f09ef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#navbar > ul.nav.navbar-nav.navbar-custom > li:nth-child(1) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#navbar > ul.nav.navbar-nav.navbar-custom > li:nth-child(1) > a</value>
   </webElementProperties>
</WebElementEntity>
