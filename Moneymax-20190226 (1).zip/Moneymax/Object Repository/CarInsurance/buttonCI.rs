<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonCI</name>
   <tag></tag>
   <elementGuidId>0f081eab-5acc-4f7f-8669-611bcabcd816</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section.header-content.no_background.no_filter > div > div > div.col-sm-8.col-md-6.three-box > div > div:nth-child(1) > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section.header-content.no_background.no_filter > div > div > div.col-sm-8.col-md-6.three-box > div > div:nth-child(1) > div</value>
   </webElementProperties>
</WebElementEntity>
