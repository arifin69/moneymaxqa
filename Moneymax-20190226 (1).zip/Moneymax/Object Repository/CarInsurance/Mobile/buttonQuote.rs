<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonQuote</name>
   <tag></tag>
   <elementGuidId>e55a24dd-329e-43a8-a31a-1e67901ab12b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section.header-content.insurance-page > div:nth-child(1) > div > div.col-md-12.double-content > div.col-sm-offset-1.col-sm-10.col-md-offset-5.col-md-2.double-box > div > div > div > div > a.btn.btn-success.btn-lg</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section.header-content.insurance-page > div:nth-child(1) > div > div.col-md-12.double-content > div.col-sm-offset-1.col-sm-10.col-md-offset-5.col-md-2.double-box > div > div > div > div > a.btn.btn-success.btn-lg</value>
   </webElementProperties>
</WebElementEntity>
