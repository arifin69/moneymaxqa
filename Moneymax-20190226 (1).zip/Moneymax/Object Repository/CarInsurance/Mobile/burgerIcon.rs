<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>burgerIcon</name>
   <tag></tag>
   <elementGuidId>bb393af5-0e29-4cc5-a5d6-e58cb215f029</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > nav > div > div.navbar-header > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > nav > div > div.navbar-header > button</value>
   </webElementProperties>
</WebElementEntity>
