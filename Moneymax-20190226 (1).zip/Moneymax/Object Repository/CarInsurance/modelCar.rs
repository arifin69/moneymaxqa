<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>modelCar</name>
   <tag></tag>
   <elementGuidId>306c0a53-8d95-417b-8e14-0964b636c775</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#step2 > div > div.hidden-xs >#car_type > option:nth-child(16)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#step2 > div > div.hidden-xs >#car_type > option:nth-child(16)</value>
   </webElementProperties>
</WebElementEntity>
