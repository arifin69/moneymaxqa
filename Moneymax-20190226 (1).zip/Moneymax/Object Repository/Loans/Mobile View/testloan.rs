<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>testloan</name>
   <tag></tag>
   <elementGuidId>8abd233e-f7a0-44fd-9bff-a7e81c46f8f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#navbar > ul.nav.navbar-nav.navbar-custom > li.dropdown.dropdown-large.open > ul > li > ul > li.col-md-2.col-sm-3.first-col-menu > ul > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#navbar > ul.nav.navbar-nav.navbar-custom > li.dropdown.dropdown-large.open > ul > li > ul > li.col-md-2.col-sm-3.first-col-menu > ul > li > a</value>
   </webElementProperties>
</WebElementEntity>
