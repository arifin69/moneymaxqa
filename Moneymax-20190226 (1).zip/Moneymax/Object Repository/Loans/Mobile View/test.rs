<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>test</name>
   <tag></tag>
   <elementGuidId>f64de935-0fe7-4974-a717-2d0fb82b757d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section.main-body > div > div > div.col-sm-6.left-side > div.get-started > div.row > div > div > div > a:nth-child(3) > div > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section.main-body > div > div > div.col-sm-6.left-side > div.get-started > div.row > div > div > div > a:nth-child(3) > div > p</value>
   </webElementProperties>
</WebElementEntity>
