<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>employmentStatus</name>
   <tag></tag>
   <elementGuidId>8b0100ef-1f48-4d9f-89f6-d74be2bc4934</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#employer_status > option:nth-child(3)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#employer_status > option:nth-child(3)</value>
   </webElementProperties>
</WebElementEntity>
