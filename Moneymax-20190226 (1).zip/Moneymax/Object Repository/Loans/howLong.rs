<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>howLong</name>
   <tag></tag>
   <elementGuidId>62296a19-31ab-4390-ba80-2fd413b9aac9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#loan-tenure > option:nth-child(5)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#loan-tenure > option:nth-child(5)</value>
   </webElementProperties>
</WebElementEntity>
